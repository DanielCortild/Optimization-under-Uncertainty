import sys
sys.path.append('../')
from ElectricityInvestmentPlanning import Problem1

###############
## Problem 1 ##
###############

# Get EVS
x_EVS, EV = Problem1.getEVS()
print("EVS Solution X: ", x_EVS)
print("EVS Value: ", EV)

# Get EEV
EEV = Problem1.getEEV(x_EVS)
print("EEV Value: ", EEV)